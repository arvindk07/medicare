export const users = [
  {
    id: 1,
    email: "master@gmail.com",
    passowrd: "123456",
    role: "master",
  },
  {
    id: 2,
    email: "therapist@gmail.com",
    passowrd: "123456",
    role: "therapist",
  },
  {
    id: 3,
    email: "patient@gmail.com",
    passowrd: "123456",
    role: "patient",
  },
  {
    id: 4,
    email: "patient@gmail.com",
    passowrd: "123456",
    role: "patient",
  },
  {
    id: 5,
    email: "organization@gmail.com",
    passowrd: "123456",
    role: "organization",
  },
  {
    id: 6,
    email: "tenant@gmail.com",
    passowrd: "123456",
    role: "tenant",
  },
];

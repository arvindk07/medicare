export const languages = [
  {
    language: "EN (US)",
    icon: "/image/flags/us.png",
    label: "EN (US)",
    store: "en",
  },
  {
    language: "DE",
    icon: "/image/flags/es.png",
    label: "DE",
    store: "es",
  },
  {
    language: "KO",
    icon: "/image/flags/ko.png",
    label: "KO",
    store: "ko",
  },
];

import { NotFound } from "@/modules/misc";
import { Route, Routes } from "react-router-dom";
import { CRMManagement } from "../pages/CRMManagement";
import { UsersManagement } from "../pages/UsersManagement";
import { RolesPermissions } from "../pages/RolesPermissions";
import { VenuesManagement } from "../pages/VenuesManagement";
import { AnalyticsDashboard } from "../pages/AnalyticsDashboard";
import { CompaniesManagement } from "../pages/CompaniesManagement";
import { TherapistsManagement } from "../pages/TherapistsManagement";
import { MasterDashboard } from "../pages/MasterDashboard";

export const MasterPanelRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<MasterDashboard />} />
      <Route path="/companies" element={<CompaniesManagement />} />
      <Route path="/venues" element={<VenuesManagement />} />
      <Route path="/therapists" element={<TherapistsManagement />} />
      <Route path="/users" element={<UsersManagement />} />
      <Route path="/roles" element={<RolesPermissions />} />
      <Route path="/analytics" element={<AnalyticsDashboard />} />
      <Route path="/crm" element={<CRMManagement />} />
      <Route path="/flow-overview" element={<UsersManagement />} />
      <Route path="/onboarding" element={<UsersManagement />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

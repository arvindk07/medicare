import { Edit, MapPin } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { IoTrashOutline } from "react-icons/io5";
import { Card, CardContent } from "@/components/ui/card";

const GridView = (props: any) => {
  const { data, handleEdit, handleDelete, title, desc } = props;
  return (
    <div className="border-t-2 pt-4">
      <div className="pb-6">
        <h2 className="text-2xl font-medium flex items-center">{title}</h2>
        <p className="text-muted-foreground text-sm">{desc}</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {data.map((company: any) => (
          <Card key={company.id}>
            <CardContent className="p-6">
              <div>
                <div className="font-medium">{company.name}</div>
                <div className="text-sm text-muted-foreground flex items-center">
                  <MapPin className="h-3 w-3 mr-1" />
                  {company.address}
                </div>
              </div>
              <div>
                <div className="text-sm">{company.email}</div>
                <div className="text-sm text-muted-foreground">
                  {company.phone}
                </div>
              </div>
              <div className="flex justify-between items-center mt-4 border-t-[1px] pt-4">
                <Badge
                  variant={
                    company.status === "Active"
                      ? "default"
                      : company.status === "Pending"
                      ? "secondary"
                      : "destructive"
                  }
                >
                  {company.status}
                </Badge>
                <div className="flex space-x-2 justify-end">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(company)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDelete(company.id)}
                  >
                    <IoTrashOutline className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default GridView;
